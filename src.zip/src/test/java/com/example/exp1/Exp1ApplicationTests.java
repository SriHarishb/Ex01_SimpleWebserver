package com.example.exp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
