package com.example.exp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Exp1Application.class, args);
	}

}
